*********************
``matplotlib.bezier``
*********************

.. automodule:: matplotlib.bezier
   :members:
   :undoc-members:
   :show-inheritance:
