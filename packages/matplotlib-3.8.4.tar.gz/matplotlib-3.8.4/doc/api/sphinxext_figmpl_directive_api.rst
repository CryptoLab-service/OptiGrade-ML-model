=========================================
``matplotlib.sphinxext.figmpl_directive``
=========================================

.. automodule:: matplotlib.sphinxext.figmpl_directive
   :no-undoc-members:
