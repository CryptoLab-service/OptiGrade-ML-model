***********************
``matplotlib.colorbar``
***********************

.. automodule:: matplotlib.colorbar
   :members:
   :undoc-members:
   :show-inheritance:
