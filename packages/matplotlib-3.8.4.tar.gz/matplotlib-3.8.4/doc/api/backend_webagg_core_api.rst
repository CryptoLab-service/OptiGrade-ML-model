*******************************************
``matplotlib.backends.backend_webagg_core``
*******************************************

.. automodule:: matplotlib.backends.backend_webagg_core
   :members:
   :undoc-members:
   :show-inheritance:
